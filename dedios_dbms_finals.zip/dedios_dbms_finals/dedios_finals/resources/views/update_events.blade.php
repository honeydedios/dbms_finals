@extends('layout.app')

@section('content')

    <div class="card my-4">
        <form action="{{route('saveUpdatedEvents', $event->id)}}" method="POST">
            @csrf
            @method('PUT')
            <div class="card-body">
                <div class="row">
                    <div class="p-2 bd-highlight">
                        <label for="EventName" class="form-label">Event Name</label>
                        <input type="text" class="form-control" name="update_event_name" value="{{$event->EventName}}">
                    </div>
                    <div class="p-2 bd-highlight">
                        <label for="Date" class="form-label">Date</label>
                        <input type="text" class="form-control" name="update_date" value="{{$event->Date}}">
                    </div>
                    <div class="p-2 bd-highlight">
                        <label for="Place" class="form-label">Place</label>
                        <input type="text" class="form-control" name="update_place" value="{{$event->Place}}">
                    </div>
                   <div class="p-2 bd-highlight">
                        <label for="Attendant" class="form-label">Attendant</label>
                        <input type="text" class="form-control" name="update_attendant"  value="{{$event->Attendant}}">
                    </div>

                    <div class="p-2 bd-highlight" justify-content-center align-items-center">
                    <a href="{{route('saveUpdatedEvents', $event->id)}}">
                            <button>
                                <span>Submit</span>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </form>
    </div>

@endsection
