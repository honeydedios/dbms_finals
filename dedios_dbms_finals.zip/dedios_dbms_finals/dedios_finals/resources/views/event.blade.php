@extends('layout.app')

@section('content')
    <style>
        h1{
            text-align: center;
            font-family: serif;
            font-size: 120px;
            padding-top: 1rem;
            padding-bottom: 1rem;
        }
        form{
            display: flex;
            gap: 0.5rem;
            padding-bottom: 1rem;
            font-size: 20px;
            font-family: Georgia, serif;
        }

        
    </style>

    <h1>Event Registration System</h1>
    
    <div>

        <div class="row">
            <form action="{{route('saveEvents')}}" method="post">
                @csrf

                <label for="EventName" class="col"></label>
                <input class="inputs" type="text" name="EventName" placeholder="Event Name">

                <label for="Date" class="col"></label>
                <input class="inputs" type="text" name="Date" placeholder="Date">

                <label for="Place" class="col"></label>
                <input class="inputs" type="text" name="Place" placeholder="Place">

                <label for="Attendant " class="col"></label>
                <input class="inputs" type="text" name="Attendant " placeholder="Attendant ">

                <div class="col">
                    <button>Add</button>
                </div>
            </form>
        </div>

        <table class="table table-dark">

            <thead>
                <tr>
                    <th>Id</th>
                    <th>Event Name</th>
                    <th>Date</th>
                    <th>Place</th>
                    <th>Attendant</th>
                </tr>   
            </thead>
            
            <tbody>
                @foreach($events as $event)
                    <tr>
                        <td>{{ $event->Id }}</td>
                        <td>{{ $event->EventName }}</td>
                        <td>{{ $event->Date }}</td>
                        <td>{{ $event->Place }}</td>
                        <td>{{ $event->Attendant }}</td>
                        <td>
                            <a href="{{route('updateEvents', $event->id)}}">
                                <button>Edit</button>
                            </a>
                        </td>

                        <td>
                            <a href="{{route('removeEvents', $event->id)}}">
                                <button>Delete</button>
                            </a>
                        </td>
                    </tr> 
                @endforeach
            </tbody>
        </table>
    </div>

@endsection

@section('title')
    Event Page
@endsection