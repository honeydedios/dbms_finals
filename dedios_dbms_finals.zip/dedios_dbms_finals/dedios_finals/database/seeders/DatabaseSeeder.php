<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Event;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // \App\Models\User::factory(10)->create();

        User::factory()->create([
            'username' => 'admin',
            'password' => 'root',
        ]);

        Event::factory()->create([
            'event_name' => 'Ewan',
            'date' => 'September 10, 2024'
            'place' => 'Balanga',
            'attendant' => ['Honey, Dedios'],
        ]);
    }
}
